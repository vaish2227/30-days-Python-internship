import mymodule
print(mymodule.mymodule1(mymodule.list1))
mymodule.list1[1]="abc"
list2=["gayu","praju","riya"]
print(mymodule.mymodule1(list2))